package com.assignment.restassured.UiBank;

public class RestassuredBase {

	public static String id;
	public static String userId;
}
